import axios from 'axios';

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || 'http://localhost:8080/api' });

api.interceptors.request.use((cfg) => {
  try {
    const u = JSON.parse(sessionStorage.getItem('fp_user'));
    if (u?.token) cfg.headers.Authorization = `Bearer ${u.token}`;
  } catch { /* ignore */ }
  return cfg;
});

api.interceptors.response.use((r) => r, (err) => {
  const url = err.config?.url || '';
  if (err.response?.status === 401 && !url.startsWith('/auth/')) window.dispatchEvent(new Event('fp:unauthorized'));
  return Promise.reject(err);
});

export const errMsg = (e) => e.response?.data?.message || (e.response?.status === 403 ? 'You do not have permission to do that.' : 'Something went wrong. Please try again.');
export default api;
