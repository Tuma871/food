import { useState } from 'react';
import api, { errMsg } from '../api';

const lines = (s) => s.split('\n').map((x) => x.trim()).filter(Boolean);

export default function PracticalForm({ initial, onSaved, onCancel }) {
  const [f, setF] = useState({
    title: initial?.title || '', duration: initial?.duration || '', imageUrl: initial?.imageUrl || '',
    summary: initial?.summary || '', objective: initial?.objective || '', expectedResults: initial?.expectedResults || '',
    materials: (initial?.materials || []).join('\n'), steps: (initial?.steps || []).join('\n'), safetyTips: (initial?.safetyTips || []).join('\n'),
  });
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault(); setErr('');
    const body = { ...f, materials: lines(f.materials), steps: lines(f.steps), safetyTips: lines(f.safetyTips) };
    try {
      const { data } = initial?.id ? await api.put(`/practicals/${initial.id}`, body) : await api.post('/practicals', body);
      onSaved(data);
    } catch (e2) { setErr(errMsg(e2)); }
  };

  return (
    <form className="card form" onSubmit={submit}>
      <h3>{initial?.id ? 'Edit practical' : 'Add new practical'}</h3>
      {err && <div className="alert error">{err}</div>}
      <label>Title<input required value={f.title} onChange={set('title')} maxLength={200} /></label>
      <label>Duration<input value={f.duration} onChange={set('duration')} /></label>
      <label>Photo URL (optional, https image link)<input value={f.imageUrl} onChange={set('imageUrl')} placeholder="https://..." /></label>
      <label>Summary<textarea rows={2} value={f.summary} onChange={set('summary')} /></label>
      <label>Objective<textarea rows={3} value={f.objective} onChange={set('objective')} /></label>
      <label>Materials (one per line)<textarea rows={5} value={f.materials} onChange={set('materials')} /></label>
      <label>Step-by-step procedure (one step per line)<textarea rows={8} value={f.steps} onChange={set('steps')} /></label>
      <label>Safety tips (one per line)<textarea rows={3} value={f.safetyTips} onChange={set('safetyTips')} /></label>
      <label>Expected results<textarea rows={3} value={f.expectedResults} onChange={set('expectedResults')} /></label>
      <div className="row"><button className="btn">Save</button><button type="button" className="btn ghost" onClick={onCancel}>Cancel</button></div>
    </form>
  );
}
