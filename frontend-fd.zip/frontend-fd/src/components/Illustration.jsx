// Inline SVG illustrations (no external images needed). If a practical has an imageUrl, that photo is shown instead.
const bg = { principles: '#E8F5E9', blanching: '#E0F2F1', chilling: '#E1F5FE', jelly: '#FCE4EC', preservatives: '#FFF3E0', dehydration: '#FFF8E1', pickling: '#F1F8E9' };

function Jar({ fill, lid = '#8D6E63', children }) {
  return (
    <g>
      <rect x="70" y="34" width="60" height="14" rx="4" fill={lid} />
      <path d="M72 48h56v8c10 6 14 14 14 26v50c0 10-6 16-16 16H74c-10 0-16-6-16-16V82c0-12 4-20 14-26z" fill="#fff" stroke="#2E7D32" strokeWidth="4" />
      <path d="M62 92h76v44c0 6-4 10-10 10H72c-6 0-10-4-10-10z" fill={fill} opacity=".9" />
      {children}
    </g>
  );
}

const art = {
  principles: (<><Jar fill="#EF5350"><circle cx="90" cy="118" r="10" fill="#C62828" /><circle cx="112" cy="124" r="9" fill="#C62828" /></Jar><path d="M150 40l16 8v16c0 14-8 22-16 26-8-4-16-12-16-26V48z" fill="#2E7D32" /><path d="M143 62l5 6 10-12" stroke="#fff" strokeWidth="4" fill="none" /></>),
  blanching: (<><path d="M40 90h120v50c0 12-8 20-20 20H60c-12 0-20-8-20-20z" fill="#546E7A" /><rect x="32" y="82" width="136" height="10" rx="5" fill="#37474F" /><path d="M60 78c-8-12 8-16 0-28M100 78c-8-12 8-16 0-28M140 78c-8-12 8-16 0-28" stroke="#4FC3F7" strokeWidth="5" fill="none" strokeLinecap="round" /><path d="M72 120c10-18 30-18 40 0-10 14-30 14-40 0z" fill="#66BB6A" /><path d="M96 124c10-14 24-14 32 2-8 10-24 10-32-2z" fill="#2E7D32" /></>),
  chilling: (<><g stroke="#0288D1" strokeWidth="8" strokeLinecap="round"><path d="M100 30v140M40 65l120 70M40 135l120-70" /></g><g stroke="#0288D1" strokeWidth="5" strokeLinecap="round" fill="none"><path d="M88 38l12 12 12-12M88 162l12-12 12 12M44 82l17-5-5-17M156 118l-17 5 5 17M44 118l17 5-5 17M156 82l-17-5 5-17" /></g><circle cx="100" cy="100" r="10" fill="#fff" stroke="#0288D1" strokeWidth="5" /></>),
  jelly: (<><Jar fill="#E91E63" lid="#AD1457"><path d="M70 108q15-10 30 0t30 0" stroke="#F8BBD0" strokeWidth="4" fill="none" /></Jar><path d="M150 110l20-30 6 4-18 32z" fill="#8D6E63" /><ellipse cx="148" cy="118" rx="12" ry="8" fill="#E91E63" /></>),
  preservatives: (<><path d="M85 30h30v30l25 70c4 14-4 30-18 30H78c-14 0-22-16-18-30l25-70z" fill="#fff" stroke="#EF6C00" strokeWidth="4" /><path d="M66 128h68l6 20c2 8-2 18-12 18H72c-10 0-14-10-12-18z" fill="#FFB74D" /><rect x="82" y="24" width="36" height="10" rx="4" fill="#8D6E63" /><circle cx="90" cy="145" r="5" fill="#fff" /><circle cx="112" cy="138" r="4" fill="#fff" /></>),
  dehydration: (<><circle cx="100" cy="64" r="28" fill="#FDD835" /><g stroke="#F9A825" strokeWidth="6" strokeLinecap="round">{[0,45,90,135,180,225,270,315].map(a => <line key={a} x1={100 + 38 * Math.cos(a * Math.PI / 180)} y1={64 + 38 * Math.sin(a * Math.PI / 180)} x2={100 + 50 * Math.cos(a * Math.PI / 180)} y2={64 + 50 * Math.sin(a * Math.PI / 180)} />)}</g><rect x="35" y="140" width="130" height="8" rx="4" fill="#8D6E63" /><ellipse cx="70" cy="132" rx="22" ry="9" fill="#FF8F00" /><ellipse cx="108" cy="132" rx="18" ry="9" fill="#FFB300" /><ellipse cx="140" cy="132" rx="14" ry="8" fill="#E65100" /></>),
  pickling: (<><Jar fill="#C5E1A5" lid="#2E7D32"><rect x="76" y="92" width="14" height="48" rx="7" fill="#388E3C" /><rect x="96" y="86" width="14" height="54" rx="7" fill="#2E7D32" /><rect x="116" y="96" width="12" height="44" rx="6" fill="#43A047" /><circle cx="94" cy="104" r="3" fill="#FDD835" /><circle cx="112" cy="116" r="3" fill="#FDD835" /></Jar></>),
};

export default function Illustration({ practical, size = 200 }) {
  if (practical?.imageUrl) return <img className="photo" src={practical.imageUrl} alt={practical.title} loading="lazy" referrerPolicy="no-referrer" />;
  const slug = practical?.slug;
  return (
    <svg viewBox="0 0 200 200" width={size} height={size} role="img" aria-label={practical?.title || 'Food preservation'} className="illus" style={{ background: bg[slug] || '#E8F5E9' }}>
      {art[slug] || art.principles}
    </svg>
  );
}
