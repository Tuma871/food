import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  return (
    <header className="navbar">
      <Link to="/" className="brand">🥫 Food Preservation Lab</Link>
      <nav>
        {user && <NavLink to="/practicals">Practicals</NavLink>}
        {user && <NavLink to="/dashboard">My Dashboard</NavLink>}
        {!user && <NavLink to="/login">Login</NavLink>}
        {!user && <NavLink to="/register" className="btn small">Register</NavLink>}
        {user && (
          <>
            <span className="who">{user.fullName} <span className={`badge ${user.role}`}>{user.role}</span></span>
            <button className="btn small ghost" onClick={() => { logout(); nav('/'); }}>Logout</button>
          </>
        )}
      </nav>
    </header>
  );
}
