import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api';
import PracticalForm from './PracticalForm';

export default function ManagePracticals({ canDelete }) {
  const [list, setList] = useState([]);
  const [editing, setEditing] = useState(null); // null | {} (new) | practical
  const [err, setErr] = useState('');
  const load = () => api.get('/practicals').then((r) => setList(r.data)).catch((e) => setErr(errMsg(e)));
  useEffect(() => { load(); }, []);

  const remove = async (p) => {
    if (!window.confirm(`Delete "${p.title}" and all student submissions for it?`)) return;
    try { await api.delete(`/practicals/${p.id}`); load(); } catch (e) { setErr(errMsg(e)); }
  };

  if (editing) return <PracticalForm initial={editing} onCancel={() => setEditing(null)} onSaved={() => { setEditing(null); load(); }} />;
  return (
    <div>
      {err && <div className="alert error">{err}</div>}
      <button className="btn" onClick={() => setEditing({})}>+ Add practical</button>
      <div className="table-wrap"><table>
        <thead><tr><th>#</th><th>Title</th><th>Steps</th><th>Actions</th></tr></thead>
        <tbody>{list.map((p, i) => (
          <tr key={p.id}><td>{i + 1}</td><td><Link to={`/practicals/${p.id}`}>{p.title}</Link></td><td>{p.steps.length}</td>
            <td className="row"><button className="btn small" onClick={() => setEditing(p)}>Edit</button>
              {canDelete && <button className="btn small danger" onClick={() => remove(p)}>Delete</button>}</td></tr>
        ))}</tbody>
      </table></div>
    </div>
  );
}
