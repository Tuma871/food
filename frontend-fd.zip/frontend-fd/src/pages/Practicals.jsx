import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api';
import Illustration from '../components/Illustration';

export default function Practicals() {
  const [list, setList] = useState(null);
  const [err, setErr] = useState('');
  useEffect(() => { api.get('/practicals').then((r) => setList(r.data)).catch((e) => setErr(errMsg(e))); }, []);
  if (err) return <div className="alert error">{err}</div>;
  if (!list) return <p>Loading practicals…</p>;
  return (
    <>
      <h1>Food Preservation Practicals</h1>
      <div className="grid">
        {list.map((p, i) => (
          <Link to={`/practicals/${p.id}`} className="card lift center" key={p.id}>
            <Illustration practical={p} size={160} />
            <span className="tag">Practical {i + 1}</span>
            <h3>{p.title}</h3>
            <p>{p.summary}</p>
            <small>⏱ {p.duration}</small>
          </Link>
        ))}
      </div>
    </>
  );
}
