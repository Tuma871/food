import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import ManagePracticals from '../components/ManagePracticals';

export default function AdminDashboard() {
  const [tab, setTab] = useState('users');
  const [stats, setStats] = useState({});
  const [users, setUsers] = useState([]);
  const [err, setErr] = useState('');
  const [f, setF] = useState({ fullName: '', email: '', password: '', role: 'LECTURER' });
  const load = () => Promise.all([api.get('/admin/stats'), api.get('/admin/users')]).then(([a, b]) => { setStats(a.data); setUsers(b.data); }).catch((e) => setErr(errMsg(e)));
  useEffect(() => { load(); }, []);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const create = async (e) => {
    e.preventDefault(); setErr('');
    try { await api.post('/admin/users', f); setF({ fullName: '', email: '', password: '', role: 'LECTURER' }); load(); } catch (x) { setErr(errMsg(x)); }
  };
  const toggle = async (u) => { try { await api.patch(`/admin/users/${u.id}/enabled`, null, { params: { value: !u.enabled } }); load(); } catch (x) { setErr(errMsg(x)); } };
  const remove = async (u) => { if (!window.confirm(`Delete ${u.email}?`)) return; try { await api.delete(`/admin/users/${u.id}`); load(); } catch (x) { setErr(errMsg(x)); } };

  return (
    <>
      <h1>Administrator Dashboard</h1>
      <div className="stats">
        {[['students', 'Students'], ['lecturers', 'Lecturers'], ['admins', 'Admins'], ['practicals', 'Practicals'], ['submissions', 'Submissions']].map(([k, l]) => <div className="stat" key={k}><b>{stats[k] ?? '–'}</b><span>{l}</span></div>)}
      </div>
      <div className="tabs"><button className={tab === 'users' ? 'on' : ''} onClick={() => setTab('users')}>User management</button>
        <button className={tab === 'prac' ? 'on' : ''} onClick={() => setTab('prac')}>Manage practicals</button></div>
      {err && <div className="alert error">{err}</div>}
      {tab === 'users' ? (
        <>
          <form className="card form inline" onSubmit={create}>
            <h3>Create user</h3>
            <input required placeholder="Full name" value={f.fullName} onChange={set('fullName')} />
            <input required type="email" placeholder="Email" value={f.email} onChange={set('email')} />
            <input required type="password" placeholder="Temporary password" autoComplete="new-password" value={f.password} onChange={set('password')} />
            <select value={f.role} onChange={set('role')}><option>LECTURER</option><option>STUDENT</option><option>ADMIN</option></select>
            <button className="btn">Create</button>
          </form>
          <div className="table-wrap"><table>
            <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead>
            <tbody>{users.map((u) => (
              <tr key={u.id}><td>{u.fullName}</td><td>{u.email}</td><td><span className={`badge ${u.role}`}>{u.role}</span></td>
                <td><span className={`pill ${u.enabled ? 'ok' : ''}`}>{u.enabled ? 'Active' : 'Disabled'}</span></td>
                <td className="row"><button className="btn small ghost" onClick={() => toggle(u)}>{u.enabled ? 'Disable' : 'Enable'}</button>
                  <button className="btn small danger" onClick={() => remove(u)}>Delete</button></td></tr>))}</tbody>
          </table></div>
        </>
      ) : <ManagePracticals canDelete />}
    </>
  );
}
