import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext';
import Illustration from '../components/Illustration';

export default function PracticalDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const [p, setP] = useState(null);
  const [mine, setMine] = useState(null);
  const [notes, setNotes] = useState('');
  const [msg, setMsg] = useState(null);

  useEffect(() => {
    api.get(`/practicals/${id}`).then((r) => setP(r.data)).catch((e) => setMsg({ t: 'error', m: errMsg(e) }));
    if (user.role === 'STUDENT') api.get('/progress/me').then((r) => {
      const m = r.data.find((x) => String(x.practicalId) === id); setMine(m || null); setNotes(m?.notes || '');
    });
  }, [id, user.role]);

  const save = async (completed) => {
    try { const { data } = await api.put(`/progress/me/${id}`, { completed, notes }); setMine(data); setMsg({ t: 'ok', m: completed ? 'Marked as completed. Your lecturer can now grade it.' : 'Draft saved.' }); }
    catch (e) { setMsg({ t: 'error', m: errMsg(e) }); }
  };

  if (!p) return msg ? <div className="alert error">{msg.m}</div> : <p>Loading…</p>;
  return (
    <article className="practical">
      <Link to="/practicals">← All practicals</Link>
      <header className="p-head">
        <Illustration practical={p} size={200} />
        <div><h1>{p.title}</h1><p className="lead">{p.summary}</p><span className="tag">⏱ {p.duration}</span></div>
      </header>

      <section className="card"><h2>🎯 Objective</h2><p>{p.objective}</p></section>
      <section className="card"><h2>🧰 Materials and equipment</h2><ul className="check">{p.materials.map((m, i) => <li key={i}>{m}</li>)}</ul></section>
      <section className="card"><h2>👣 Step-by-step procedure</h2>
        <ol className="steps">{p.steps.map((s, i) => <li key={i}><span className="num">{i + 1}</span><p>{s}</p></li>)}</ol>
      </section>
      {p.safetyTips?.length > 0 && <section className="card warn"><h2>⚠️ Safety tips</h2><ul>{p.safetyTips.map((s, i) => <li key={i}>{s}</li>)}</ul></section>}
      <section className="card"><h2>✅ Expected results</h2><p>{p.expectedResults}</p></section>

      {user.role === 'STUDENT' && (
        <section className="card form">
          <h2>📝 My practical report</h2>
          {msg && <div className={`alert ${msg.t}`}>{msg.m}</div>}
          <textarea rows={6} value={notes} onChange={(e) => setNotes(e.target.value)} maxLength={4000} placeholder="Record your observations, results and conclusion…" />
          <div className="row"><button className="btn" onClick={() => save(true)}>Submit as completed</button><button className="btn ghost" onClick={() => save(false)}>Save draft</button></div>
          {mine?.score != null && <div className="alert ok"><strong>Score: {mine.score}/100</strong>{mine.feedback && <> · Feedback: {mine.feedback}</>}</div>}
        </section>
      )}
    </article>
  );
}
