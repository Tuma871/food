import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import Illustration from '../components/Illustration';

const topics = [
  ['principles', 'Principles of Food Preservation'], ['blanching', 'Blanching of Vegetables'], ['chilling', 'Chilling'],
  ['jelly', 'Jelly Preparation'], ['preservatives', 'Food Preservatives'], ['dehydration', 'Dehydration'], ['pickling', 'Pickling'],
];

export default function Home() {
  const { user } = useAuth();
  return (
    <>
      <section className="hero">
        <div>
          <h1>Learn to keep food fresh, safe and delicious</h1>
          <p>Seven hands-on practicals with complete step-by-step procedures, safety guidance and expected results, for students, lecturers and administrators.</p>
          <div className="row">
            {user ? <Link className="btn" to="/practicals">Open practicals</Link> : <><Link className="btn" to="/login">Login</Link><Link className="btn ghost" to="/register">Create student account</Link></>}
          </div>
        </div>
        <Illustration practical={{ slug: 'pickling' }} size={260} />
      </section>
      <h2>Practicals covered</h2>
      <div className="grid">
        {topics.map(([slug, title], i) => (
          <div className="card center" key={slug}>
            <Illustration practical={{ slug, title }} size={140} />
            <h3>{i + 1}. {title}</h3>
          </div>
        ))}
      </div>
    </>
  );
}
