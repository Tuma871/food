import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../AuthContext';
import { errMsg } from '../api';

const rules = [
  ['At least 8 characters', (p) => p.length >= 8], ['Lowercase letter', (p) => /[a-z]/.test(p)], ['Uppercase letter', (p) => /[A-Z]/.test(p)],
  ['A number', (p) => /\d/.test(p)], ['A symbol', (p) => /[^\w\s]/.test(p)],
];

export default function Register() {
  const { register } = useAuth();
  const nav = useNavigate();
  const [f, setF] = useState({ fullName: '', email: '', password: '' });
  const [err, setErr] = useState('');
  const ok = rules.every(([, t]) => t(f.password));
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault(); setErr('');
    try { await register(f.fullName, f.email, f.password); nav('/dashboard'); } catch (x) { setErr(errMsg(x)); }
  };
  return (
    <form className="card form narrow" onSubmit={submit}>
      <h2>Student registration</h2>
      {err && <div className="alert error" role="alert">{err}</div>}
      <label>Full name<input required maxLength={100} value={f.fullName} onChange={set('fullName')} /></label>
      <label>Email<input type="email" required value={f.email} onChange={set('email')} /></label>
      <label>Password<input type="password" required autoComplete="new-password" value={f.password} onChange={set('password')} /></label>
      <ul className="rules">{rules.map(([l, t]) => <li key={l} className={t(f.password) ? 'ok' : ''}>{t(f.password) ? '✓' : '○'} {l}</li>)}</ul>
      <button className="btn" disabled={!ok}>Create account</button>
      <p>Already registered? <Link to="/login">Login</Link></p>
      <small>Lecturer and administrator accounts are created by an administrator.</small>
    </form>
  );
}
