import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api, { errMsg } from '../api';
import { useAuth } from '../AuthContext';

export default function StudentDashboard() {
  const { user } = useAuth();
  const [practicals, setP] = useState([]);
  const [prog, setProg] = useState([]);
  const [err, setErr] = useState('');
  useEffect(() => {
    Promise.all([api.get('/practicals'), api.get('/progress/me')]).then(([a, b]) => { setP(a.data); setProg(b.data); }).catch((e) => setErr(errMsg(e)));
  }, []);
  const by = Object.fromEntries(prog.map((x) => [x.practicalId, x]));
  const done = prog.filter((x) => x.completed).length;
  const graded = prog.filter((x) => x.score != null);
  const avg = graded.length ? Math.round(graded.reduce((s, x) => s + x.score, 0) / graded.length) : null;
  const pct = practicals.length ? Math.round((done / practicals.length) * 100) : 0;

  return (
    <>
      <h1>Hello, {user.fullName} 👋</h1>
      {err && <div className="alert error">{err}</div>}
      <div className="stats">
        <div className="stat"><b>{done}/{practicals.length}</b><span>Practicals completed</span></div>
        <div className="stat"><b>{avg ?? '–'}</b><span>Average score</span></div>
        <div className="stat"><b>{graded.length}</b><span>Graded reports</span></div>
      </div>
      <div className="progress" aria-label="progress"><div style={{ width: `${pct}%` }} /></div>
      <h2>My practicals</h2>
      <div className="table-wrap"><table>
        <thead><tr><th>Practical</th><th>Status</th><th>Score</th><th>Lecturer feedback</th></tr></thead>
        <tbody>{practicals.map((p) => { const x = by[p.id]; return (
          <tr key={p.id}><td><Link to={`/practicals/${p.id}`}>{p.title}</Link></td>
            <td><span className={`pill ${x?.completed ? 'ok' : ''}`}>{x?.completed ? 'Completed' : x ? 'Draft' : 'Not started'}</span></td>
            <td>{x?.score ?? '–'}</td><td>{x?.feedback || '–'}</td></tr>); })}</tbody>
      </table></div>
    </>
  );
}
