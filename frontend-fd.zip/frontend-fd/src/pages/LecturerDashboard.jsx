import { useEffect, useState } from 'react';
import api, { errMsg } from '../api';
import ManagePracticals from '../components/ManagePracticals';

function Row({ s, onSaved }) {
  const [score, setScore] = useState(s.score ?? '');
  const [feedback, setFeedback] = useState(s.feedback ?? '');
  const [msg, setMsg] = useState('');
  const save = async () => {
    try { const { data } = await api.put(`/progress/${s.id}/grade`, { score: score === '' ? null : Number(score), feedback }); onSaved(data); setMsg('Saved'); }
    catch (e) { setMsg(errMsg(e)); }
  };
  return (
    <tr>
      <td>{s.studentName}<br /><small>{s.studentEmail}</small></td><td>{s.practicalTitle}</td>
      <td><span className={`pill ${s.completed ? 'ok' : ''}`}>{s.completed ? 'Submitted' : 'Draft'}</span></td>
      <td className="notes">{s.notes || <em>No notes</em>}</td>
      <td><input className="score" type="number" min="0" max="100" value={score} onChange={(e) => setScore(e.target.value)} /></td>
      <td><input value={feedback} onChange={(e) => setFeedback(e.target.value)} maxLength={1000} /></td>
      <td><button className="btn small" onClick={save}>Save</button><small> {msg}</small></td>
    </tr>
  );
}

export default function LecturerDashboard() {
  const [tab, setTab] = useState('sub');
  const [rows, setRows] = useState([]);
  const [err, setErr] = useState('');
  useEffect(() => { api.get('/progress').then((r) => setRows(r.data)).catch((e) => setErr(errMsg(e))); }, []);
  const replace = (n) => setRows(rows.map((r) => (r.id === n.id ? n : r)));
  const pending = rows.filter((r) => r.completed && r.score == null).length;

  return (
    <>
      <h1>Lecturer Dashboard</h1>
      <div className="stats">
        <div className="stat"><b>{rows.length}</b><span>Student records</span></div>
        <div className="stat"><b>{pending}</b><span>Awaiting grading</span></div>
        <div className="stat"><b>{new Set(rows.map((r) => r.studentId)).size}</b><span>Active students</span></div>
      </div>
      <div className="tabs"><button className={tab === 'sub' ? 'on' : ''} onClick={() => setTab('sub')}>Student submissions</button>
        <button className={tab === 'prac' ? 'on' : ''} onClick={() => setTab('prac')}>Manage practicals</button></div>
      {err && <div className="alert error">{err}</div>}
      {tab === 'sub' ? (
        <div className="table-wrap"><table>
          <thead><tr><th>Student</th><th>Practical</th><th>Status</th><th>Report</th><th>Score</th><th>Feedback</th><th></th></tr></thead>
          <tbody>{rows.length ? rows.map((s) => <Row key={s.id} s={s} onSaved={replace} />) : <tr><td colSpan="7">No submissions yet.</td></tr>}</tbody>
        </table></div>
      ) : <ManagePracticals canDelete={false} />}
    </>
  );
}
