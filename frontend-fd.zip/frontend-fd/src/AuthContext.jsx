import { createContext, useContext, useState, useEffect, useCallback } from 'react';
import api from './api';

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

const expiry = (t) => { try { return JSON.parse(atob(t.split('.')[1].replace(/-/g, '+').replace(/_/g, '/'))).exp * 1000; } catch { return 0; } };
const stored = () => { try { const u = JSON.parse(sessionStorage.getItem('fp_user')); return u && expiry(u.token) > Date.now() ? u : null; } catch { return null; } };

export function AuthProvider({ children }) {
  const [user, setUser] = useState(stored);
  const logout = useCallback(() => { sessionStorage.removeItem('fp_user'); setUser(null); }, []);
  const save = (data) => { sessionStorage.setItem('fp_user', JSON.stringify(data)); setUser(data); return data; };

  const login = async (email, password) => save((await api.post('/auth/login', { email, password })).data);
  const register = async (fullName, email, password) => save((await api.post('/auth/register', { fullName, email, password })).data);

  useEffect(() => {
    window.addEventListener('fp:unauthorized', logout);
    return () => window.removeEventListener('fp:unauthorized', logout);
  }, [logout]);

  // auto-logout when the token expires
  useEffect(() => {
    if (!user) return;
    const t = setTimeout(logout, Math.max(expiry(user.token) - Date.now(), 0));
    return () => clearTimeout(t);
  }, [user, logout]);

  return <Ctx.Provider value={{ user, login, register, logout }}>{children}</Ctx.Provider>;
}
