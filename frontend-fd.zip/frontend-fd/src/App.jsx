import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './AuthContext';
import Navbar from './components/Navbar';
import ProtectedRoute from './components/ProtectedRoute';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Practicals from './pages/Practicals';
import PracticalDetail from './pages/PracticalDetail';
import StudentDashboard from './pages/StudentDashboard';
import LecturerDashboard from './pages/LecturerDashboard';
import AdminDashboard from './pages/AdminDashboard';

const home = { ADMIN: '/admin', LECTURER: '/lecturer', STUDENT: '/student' };

export default function App() {
  const { user } = useAuth();
  return (
    <>
      <Navbar />
      <main className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={user ? <Navigate to={home[user.role]} /> : <Login />} />
          <Route path="/register" element={user ? <Navigate to={home[user.role]} /> : <Register />} />
          <Route path="/dashboard" element={user ? <Navigate to={home[user.role]} /> : <Navigate to="/login" />} />
          <Route path="/practicals" element={<ProtectedRoute><Practicals /></ProtectedRoute>} />
          <Route path="/practicals/:id" element={<ProtectedRoute><PracticalDetail /></ProtectedRoute>} />
          <Route path="/student" element={<ProtectedRoute roles={['STUDENT']}><StudentDashboard /></ProtectedRoute>} />
          <Route path="/lecturer" element={<ProtectedRoute roles={['LECTURER']}><LecturerDashboard /></ProtectedRoute>} />
          <Route path="/admin" element={<ProtectedRoute roles={['ADMIN']}><AdminDashboard /></ProtectedRoute>} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
      <footer className="footer">Food Preservation Lab System · Keep it fresh, keep it safe</footer>
    </>
  );
}
