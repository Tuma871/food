package com.example.food.repository;
import com.example.food.model.Progress;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;
public interface ProgressRepository extends JpaRepository<Progress, Long> {
    List<Progress> findByStudentId(Long studentId);
    Optional<Progress> findByStudentIdAndPracticalId(Long studentId, Long practicalId);
    void deleteByStudentId(Long studentId);
    void deleteByPracticalId(Long practicalId);
}
