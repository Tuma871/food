package com.example.food.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.Map;
import java.util.NoSuchElementException;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private ResponseEntity<Map<String, String>> r(HttpStatus s, String m) { return ResponseEntity.status(s).body(Map.of("message", m)); }

    @ExceptionHandler(BadCredentialsException.class) ResponseEntity<?> bad(Exception e) { return r(HttpStatus.UNAUTHORIZED, "Invalid email or password"); }
    @ExceptionHandler(LockedException.class) ResponseEntity<?> locked(Exception e) { return r(HttpStatus.LOCKED, "Account temporarily locked after repeated failed logins. Try again later."); }
    @ExceptionHandler(DisabledException.class) ResponseEntity<?> disabled(Exception e) { return r(HttpStatus.FORBIDDEN, "Account is disabled. Contact the administrator."); }
    @ExceptionHandler(MethodArgumentNotValidException.class)
    ResponseEntity<?> invalid(MethodArgumentNotValidException e) {
        return r(HttpStatus.BAD_REQUEST, e.getBindingResult().getFieldErrors().stream().findFirst()
                .map(f -> f.getDefaultMessage()).orElse("Invalid input"));
    }
    @ExceptionHandler(IllegalArgumentException.class) ResponseEntity<?> arg(IllegalArgumentException e) { return r(HttpStatus.BAD_REQUEST, e.getMessage()); }
    @ExceptionHandler(NoSuchElementException.class) ResponseEntity<?> nf(Exception e) { return r(HttpStatus.NOT_FOUND, "Not found"); }
}
