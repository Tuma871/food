package com.example.food.model;
public enum Role { ADMIN, LECTURER, STUDENT }
