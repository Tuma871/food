package com.example.food.model;

import jakarta.persistence.*;
import lombok.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Getter @Setter @NoArgsConstructor
public class Practical {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(unique = true) private String slug;
    private int sortOrder;
    @Column(nullable = false) private String title;
    private String duration;
    private String imageUrl;
    @Column(length = 1000) private String summary;
    @Column(length = 2000) private String objective;
    @Column(length = 2000) private String expectedResults;

    @ElementCollection(fetch = FetchType.EAGER) @OrderColumn @Column(length = 1500)
    private List<String> materials = new ArrayList<>();
    @ElementCollection(fetch = FetchType.EAGER) @OrderColumn @Column(length = 2000)
    private List<String> steps = new ArrayList<>();
    @ElementCollection(fetch = FetchType.EAGER) @OrderColumn @Column(length = 1000)
    private List<String> safetyTips = new ArrayList<>();
}
