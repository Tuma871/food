package com.example.food.repository;
import com.example.food.model.Practical;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface PracticalRepository extends JpaRepository<Practical, Long> {
    List<Practical> findAllByOrderBySortOrderAscIdAsc();
}
