package com.example.food.controller;

import com.example.food.dto.Dtos.PracticalRequest;
import com.example.food.model.Practical;
import com.example.food.repository.PracticalRepository;
import com.example.food.repository.ProgressRepository;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

@RestController @RequestMapping("/api/practicals")
public class PracticalController {
    private final PracticalRepository repo;
    private final ProgressRepository progress;
    public PracticalController(PracticalRepository repo, ProgressRepository progress) { this.repo = repo; this.progress = progress; }

    @GetMapping public List<Practical> all() { return repo.findAllByOrderBySortOrderAscIdAsc(); }
    @GetMapping("/{id}") public Practical one(@PathVariable Long id) { return repo.findById(id).orElseThrow(); }

    @PostMapping @PreAuthorize("hasAnyRole('LECTURER','ADMIN')")
    public Practical create(@Valid @RequestBody PracticalRequest r) {
        Practical p = new Practical();
        p.setSortOrder((int) repo.count() + 1);
        return repo.save(apply(p, r));
    }

    @PutMapping("/{id}") @PreAuthorize("hasAnyRole('LECTURER','ADMIN')")
    public Practical update(@PathVariable Long id, @Valid @RequestBody PracticalRequest r) {
        return repo.save(apply(repo.findById(id).orElseThrow(NoSuchElementException::new), r));
    }

    @DeleteMapping("/{id}") @PreAuthorize("hasRole('ADMIN')") @Transactional
    public void delete(@PathVariable Long id) { progress.deleteByPracticalId(id); repo.deleteById(id); }

    private Practical apply(Practical p, PracticalRequest r) {
        p.setTitle(r.title().trim()); p.setDuration(r.duration()); p.setImageUrl(blankToNull(r.imageUrl()));
        p.setSummary(r.summary()); p.setObjective(r.objective()); p.setExpectedResults(r.expectedResults());
        p.setMaterials(clean(r.materials())); p.setSteps(clean(r.steps())); p.setSafetyTips(clean(r.safetyTips()));
        return p;
    }
    private static String blankToNull(String s) { return s == null || s.isBlank() ? null : s.trim(); }
    private static List<String> clean(List<String> l) {
        List<String> out = new ArrayList<>();
        if (l != null) for (String s : l) if (s != null && !s.isBlank()) out.add(s.trim());
        return out;
    }
}
