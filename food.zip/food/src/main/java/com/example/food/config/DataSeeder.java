package com.example.food.config;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.food.model.Practical;
import com.example.food.model.Role;
import com.example.food.repository.PracticalRepository;
import com.example.food.repository.UserRepository;
import com.example.food.service.AuthService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.List;

@Component
public class DataSeeder implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(DataSeeder.class);
    private final PracticalRepository practicals; private final UserRepository users; private final AuthService auth;
    public DataSeeder(PracticalRepository p, UserRepository u, AuthService a) { practicals = p; users = u; auth = a; }

    @Override public void run(String... args) throws Exception {
        if (practicals.count() == 0) {
            try (InputStream in = getClass().getResourceAsStream("/practicals.json")) {
                List<Practical> list = new ObjectMapper().readValue(in, new TypeReference<>() {});
                int i = 1; for (Practical p : list) { p.setSortOrder(i++); practicals.save(p); }
            }
        }
        if (users.count() == 0) {
            auth.create("System Administrator", "admin@foodpres.local", "Admin@12345", Role.ADMIN);
            auth.create("Dr. Lecturer", "lecturer@foodpres.local", "Lecturer@12345", Role.LECTURER);
            auth.create("Demo Student", "student@foodpres.local", "Student@12345", Role.STUDENT);
            log.warn("Demo accounts created. CHANGE OR DELETE THEM before deploying to production.");
        }
    }
}
