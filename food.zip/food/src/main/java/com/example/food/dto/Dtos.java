package com.example.food.dto;

import com.example.food.model.Role;
import jakarta.validation.constraints.*;
import java.time.Instant;
import java.util.List;

public final class Dtos {
    private Dtos() {}
    public static final String PW_RULE = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[^\\w\\s]).{8,64}$";
    public static final String PW_MSG = "Password must be 8-64 characters with upper, lower, digit and symbol";

    public record LoginRequest(@Email @NotBlank String email, @NotBlank String password) {}
    public record RegisterRequest(@NotBlank @Size(max = 100) String fullName,
                                  @Email @NotBlank @Size(max = 150) String email,
                                  @NotBlank @Pattern(regexp = PW_RULE, message = PW_MSG) String password) {}
    public record AdminCreateUser(@NotBlank @Size(max = 100) String fullName,
                                  @Email @NotBlank @Size(max = 150) String email,
                                  @NotBlank @Pattern(regexp = PW_RULE, message = PW_MSG) String password,
                                  @NotNull Role role) {}
    public record AuthResponse(String token, String fullName, String email, Role role) {}
    public record UserView(Long id, String fullName, String email, Role role, boolean enabled, Instant createdAt) {}
    public record PracticalRequest(@NotBlank @Size(max = 200) String title, @Size(max = 60) String duration,
                                   @Size(max = 500) String imageUrl, @Size(max = 1000) String summary,
                                   @Size(max = 2000) String objective, @Size(max = 2000) String expectedResults,
                                   List<@Size(max = 1500) String> materials,
                                   @Size(max = 40) List<@Size(max = 2000) String> steps,
                                   List<@Size(max = 1000) String> safetyTips) {}
    public record ProgressRequest(boolean completed, @Size(max = 4000) String notes) {}
    public record GradeRequest(@Min(0) @Max(100) Integer score, @Size(max = 1000) String feedback) {}
    public record ProgressView(Long id, Long studentId, String studentName, String studentEmail, Long practicalId,
                               String practicalTitle, boolean completed, String notes, Integer score,
                               String feedback, Instant updatedAt) {}
}
