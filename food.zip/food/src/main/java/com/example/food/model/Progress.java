package com.example.food.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.Instant;

@Entity @Table(uniqueConstraints = @UniqueConstraint(columnNames = {"student_id", "practical_id"}))
@Getter @Setter @NoArgsConstructor
public class Progress {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(optional = false) @JoinColumn(name = "student_id") private User student;
    @ManyToOne(optional = false) @JoinColumn(name = "practical_id") private Practical practical;
    private boolean completed;
    @Column(length = 4000) private String notes;
    private Integer score;
    @Column(length = 1000) private String feedback;
    private Instant updatedAt = Instant.now();
}
