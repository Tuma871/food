package com.example.food.security;

import com.example.food.model.User;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

@Service
public class JwtService {
    private final SecretKey key;
    private final long ttlMillis;

    public JwtService(@Value("${app.jwt.secret}") String secret,
                      @Value("${app.jwt.expiration-minutes}") long minutes) {
        if (secret.length() < 32) throw new IllegalStateException("JWT secret must be at least 32 characters");
        this.key = Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
        this.ttlMillis = minutes * 60_000;
    }

    public String generate(User u) {
        Date now = new Date();
        return Jwts.builder().subject(u.getEmail()).claim("role", u.getRole().name())
                .issuedAt(now).expiration(new Date(now.getTime() + ttlMillis)).signWith(key).compact();
    }

    /** Throws JwtException if signature/expiry is invalid. */
    public Claims parse(String token) {
        return Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload();
    }
}
