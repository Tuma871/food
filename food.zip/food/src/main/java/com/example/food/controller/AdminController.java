package com.example.food.controller;

import com.example.food.dto.Dtos.*;
import com.example.food.model.Role;
import com.example.food.model.User;
import com.example.food.repository.PracticalRepository;
import com.example.food.repository.ProgressRepository;
import com.example.food.repository.UserRepository;
import com.example.food.service.AuthService;
import jakarta.transaction.Transactional;
import jakarta.validation.Valid;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

/** All /api/admin/** routes require ROLE_ADMIN (enforced in SecurityConfig). */
@RestController @RequestMapping("/api/admin")
public class AdminController {
    private final UserRepository users; private final AuthService auth;
    private final PracticalRepository practicals; private final ProgressRepository progress;
    public AdminController(UserRepository u, AuthService a, PracticalRepository p, ProgressRepository pr) { users = u; auth = a; practicals = p; progress = pr; }

    @GetMapping("/users") public List<UserView> list() { return users.findAll().stream().map(this::view).toList(); }

    @PostMapping("/users") public UserView create(@Valid @RequestBody AdminCreateUser r) {
        return view(auth.create(r.fullName(), r.email(), r.password(), r.role()));
    }

    @PatchMapping("/users/{id}/enabled") public UserView enable(@PathVariable Long id, @RequestParam boolean value, Authentication a) {
        User u = users.findById(id).orElseThrow(NoSuchElementException::new);
        if (u.getEmail().equalsIgnoreCase(a.getName())) throw new IllegalArgumentException("You cannot disable your own account");
        u.setEnabled(value); return view(users.save(u));
    }

    @DeleteMapping("/users/{id}") @Transactional public void delete(@PathVariable Long id, Authentication a) {
        User u = users.findById(id).orElseThrow(NoSuchElementException::new);
        if (u.getEmail().equalsIgnoreCase(a.getName())) throw new IllegalArgumentException("You cannot delete your own account");
        progress.deleteByStudentId(id); users.delete(u);
    }

    @GetMapping("/stats") public Map<String, Long> stats() {
        return Map.of("admins", count(Role.ADMIN), "lecturers", count(Role.LECTURER), "students", count(Role.STUDENT),
                "practicals", practicals.count(), "submissions", progress.count());
    }
    private long count(Role r) { return users.findAll().stream().filter(u -> u.getRole() == r).count(); }
    private UserView view(User u) { return new UserView(u.getId(), u.getFullName(), u.getEmail(), u.getRole(), u.isEnabled(), u.getCreatedAt()); }
}
