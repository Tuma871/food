package com.example.food.service;

import com.example.food.dto.Dtos.*;
import com.example.food.model.Role;
import com.example.food.model.User;
import com.example.food.repository.UserRepository;
import com.example.food.security.JwtService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;

@Service
public class AuthService {
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private final JwtService jwt;
    private final int maxAttempts;
    private final long lockMinutes;

    public AuthService(UserRepository users, PasswordEncoder encoder, JwtService jwt,
                       @Value("${app.security.max-failed-attempts}") int maxAttempts,
                       @Value("${app.security.lock-minutes}") long lockMinutes) {
        this.users = users; this.encoder = encoder; this.jwt = jwt;
        this.maxAttempts = maxAttempts; this.lockMinutes = lockMinutes;
    }

    public AuthResponse login(LoginRequest req) {
        User u = users.findByEmailIgnoreCase(req.email().trim())
                .orElseThrow(() -> new BadCredentialsException("bad"));
        if (u.getLockedUntil() != null && u.getLockedUntil().isAfter(Instant.now()))
            throw new LockedException("locked");
        if (!u.isEnabled()) throw new DisabledException("disabled");
        if (!encoder.matches(req.password(), u.getPasswordHash())) {
            u.setFailedAttempts(u.getFailedAttempts() + 1);
            if (u.getFailedAttempts() >= maxAttempts) {
                u.setLockedUntil(Instant.now().plus(Duration.ofMinutes(lockMinutes)));
                u.setFailedAttempts(0);
            }
            users.save(u);
            throw new BadCredentialsException("bad");
        }
        u.setFailedAttempts(0); u.setLockedUntil(null); users.save(u);
        return new AuthResponse(jwt.generate(u), u.getFullName(), u.getEmail(), u.getRole());
    }

    /** Public self-registration always creates a STUDENT. */
    public AuthResponse register(RegisterRequest r) {
        User u = create(r.fullName(), r.email(), r.password(), Role.STUDENT);
        return new AuthResponse(jwt.generate(u), u.getFullName(), u.getEmail(), u.getRole());
    }

    public User create(String name, String email, String password, Role role) {
        if (users.existsByEmailIgnoreCase(email.trim()))
            throw new IllegalArgumentException("Email is already registered");
        User u = new User();
        u.setFullName(name.trim()); u.setEmail(email.trim().toLowerCase());
        u.setPasswordHash(encoder.encode(password)); u.setRole(role);
        return users.save(u);
    }
}
