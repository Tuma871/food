package com.example.food.controller;

import com.example.food.dto.Dtos.*;
import com.example.food.model.Progress;
import com.example.food.model.User;
import com.example.food.repository.PracticalRepository;
import com.example.food.repository.ProgressRepository;
import com.example.food.repository.UserRepository;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;
import java.util.NoSuchElementException;

@RestController @RequestMapping("/api/progress")
public class ProgressController {
    private final ProgressRepository repo; private final UserRepository users; private final PracticalRepository practicals;
    public ProgressController(ProgressRepository repo, UserRepository users, PracticalRepository practicals) {
        this.repo = repo; this.users = users; this.practicals = practicals;
    }

    /** STUDENT: only ever sees/edits their own records (identity comes from the verified token). */
    @GetMapping("/me") @PreAuthorize("hasRole('STUDENT')")
    public List<ProgressView> mine(Authentication a) { return repo.findByStudentId(me(a).getId()).stream().map(this::view).toList(); }

    @PutMapping("/me/{practicalId}") @PreAuthorize("hasRole('STUDENT')")
    public ProgressView submit(@PathVariable Long practicalId, @Valid @RequestBody ProgressRequest r, Authentication a) {
        User u = me(a);
        Progress p = repo.findByStudentIdAndPracticalId(u.getId(), practicalId).orElseGet(() -> {
            Progress n = new Progress(); n.setStudent(u);
            n.setPractical(practicals.findById(practicalId).orElseThrow(NoSuchElementException::new)); return n; });
        p.setCompleted(r.completed()); p.setNotes(r.notes()); p.setUpdatedAt(Instant.now());
        return view(repo.save(p));
    }

    @GetMapping @PreAuthorize("hasAnyRole('LECTURER','ADMIN')")
    public List<ProgressView> all() { return repo.findAll().stream().map(this::view).toList(); }

    @PutMapping("/{id}/grade") @PreAuthorize("hasRole('LECTURER')")
    public ProgressView grade(@PathVariable Long id, @Valid @RequestBody GradeRequest r) {
        Progress p = repo.findById(id).orElseThrow(NoSuchElementException::new);
        p.setScore(r.score()); p.setFeedback(r.feedback()); p.setUpdatedAt(Instant.now());
        return view(repo.save(p));
    }

    private User me(Authentication a) { return users.findByEmailIgnoreCase(a.getName()).orElseThrow(); }
    private ProgressView view(Progress p) {
        return new ProgressView(p.getId(), p.getStudent().getId(), p.getStudent().getFullName(), p.getStudent().getEmail(),
            p.getPractical().getId(), p.getPractical().getTitle(), p.isCompleted(), p.getNotes(), p.getScore(), p.getFeedback(), p.getUpdatedAt());
    }
}
